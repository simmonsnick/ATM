//Building a ATM Management System
//Enter Name, CreditCard Number, CreditCard Type, Password
// Show message your credit card statement approved
// Shows the Balance on the CreditCard
// Management System
#include <iostream>
#include <stdlib.h>
#include <string.h>
using namespace std;
class ATM {

    // Private variables used inside class
private:
    string name;
    long long card_number;
    char type[11];
    long long amount = 0;
    long long tot = 0;

    // Public variables
public:
    // Function to setting in the person's data
    void setvalue()
    {
        cout << "Enter name\n";
        cin.ignore();

        // To use space in string
        getline(cin, name);

        cout << "Enter credit card number\n";
        cin >> card_number;
        cout << "Enter credit card type\n";
        cin >> type;
        cout << "Enter Balance\n";
        cin >> tot;
    }

    // Function to display the required data
    void showdata()
    {
        cout << "Name:" << name << endl;
        cout << "credit card No:" << card_number << endl;
        cout << "credit card type:" << type << endl;
        cout << "Balance:" << tot << endl;
    }

    // Function to show the balance amount
    void showbal()
    {
        tot = tot + amount;
        cout << "\nTotal balance is: " << tot;
    }

    // Function to withdraw the amount in ATM
    void withdrawl()
    {
        int a;
        cout << "Enter amount to withdraw\n";
        cin >> a;
        tot = tot - a;
        cout << "Available Credit Card Balance is " << tot;
    }

    bool pwd()
    {
        cin.ignore();
        bool ap = 0;
        string pc ="";
        string code = "ACB";
        cout<<"Type your passcode\n:";
        //cin.ignore();
        getline(cin, pc);
        if (pc.compare(code)==0)
            ap = 1;
        return ap;
}
};

// Driver Code
int main()
{
    // Object of class
    ATM b;

    int choice;

    // Infinite while loop to choose
    // options
    while (1) {
        cout << "\n" << "" << "WELCOME" << "" << "\n\n";
        cout << "Enter Your Choice\n";
        cout << "\t1. Enter name, credit card " << "number, credit card type\n";
        cout << "\t2. Balance Request\n";
        cout << "\t3. Show Total balance\n";
        cout << "\t4. Withdrawal Money\n";
        cout << "\t5. Cancel\n";
        cin >> choice;

        // Choices to select from
        switch (choice) {
        case 1:
            b.setvalue();
            break;
        case 2:

            {
            bool p = b.pwd();

            while(!p)
            {
                cout << "Incorrect passcode, Press Enter to Continue\n";
                p = b.pwd();
            }

              b.showdata();
            }
           break;
        case 3:
            {
            bool p = b.pwd();

            while(!p)
            {
                cout << "Incorrect passcode, Press Enter to Continue\n";
                p = b.pwd();

            }

            b.showbal();

            }
            break;
        case 4:
            {
            bool p = b.pwd();

            while(!p)
            {
                cout << "Incorrect passcode, Press Enter to Continue\n";
                p = b.pwd();


            }

            b.withdrawl();

            }
            break;
        case 5:
            exit(1);
            break;
        default:
            cout << "\nInvalid choice\n";
        }
    }
}

