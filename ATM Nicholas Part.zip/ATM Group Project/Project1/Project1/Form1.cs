﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project1
{
	public partial class Form1 : Form
	{
		string CHN;
		int CC_N;
		string CT;
		double bal = 100.00;
		string custname = "Troy";
		
        
        public Form1()
		{
			InitializeComponent();
			textBox4.Text = "ENTER PIN";
		}
		
		private void label1_Click(object sender, EventArgs e)
		{
             //CHN Card Hold Name
		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{
			CHN = textBox1.Text;
			textBox2.Enabled = true;
		}
		
		private void label2_Click(object sender, EventArgs e)
		{
			//Card Number for Customer
			
		}
        
		private void textBox2_TextChanged(object sender, EventArgs e)
		{
			CC_N = int.Parse(textBox2.Text);
			textBox3.Enabled = true;
		}
		
		private void label3_Click(object sender, EventArgs e)
		{
			
			//Card Type for Customer
		}
		 
		private void textBox3_TextChanged(object sender, EventArgs e)
		{
			CT = textBox3.Text;
			textBox7.Enabled = true;
		}
		
		private void button1_Click(object sender, EventArgs e)
		{
			textBox1.Clear();
			textBox2.Clear();
			textBox3.Clear();
			textBox7.Clear();

			string message = "Access Approved";
			string title = "ATM System";
			MessageBox.Show(message, title);
		}

		
		private void label4_Click(object sender, EventArgs e)
		{
			
			//Balance Request 
		}
		
		private void textBox4_TextChanged(object sender, EventArgs e)
		{
	      button2.Enabled = true;
		}

		private void button2_Click(object sender, EventArgs e)
		{
			

			String code = textBox4.Text;

			if (code == "ACB")
			{
				label9.Text = "$ " + string.Format("{0:N2}", bal);
				label11.Text = "Customer Name : " + custname;
			}
			else
			{
				label9.Text = "Invalid PIN";
				textBox4.Text = "Try Again!";
				Refresh();

			}
            
        }

		private void label5_Click(object sender, EventArgs e)
		{
			//Show Total Balance 
		}

		private void textBox6_TextChanged(object sender, EventArgs e)
		{
			button3.Enabled = true;
		}

		private void button3_Click(object sender, EventArgs e)
		{
			String code = textBox6.Text;
			
			if (code == "ACB")
			{
				label12.Text = "$ " + string.Format("{0:N2}",bal);
				label13.Text = "Customer Name :" + custname;
			}
			else
			{
				label12.Text = "Invalid PIN";
				textBox6.Text = "Try Again!";
				Refresh();
			}
        }

		private void label6_Click(object sender, EventArgs e)
		{
			//Withdrawal Money
		}

		private void textBox5_TextChanged(object sender, EventArgs e)
		{
			button4.Enabled = true;
		}

		private void button4_Click(object sender, EventArgs e)
		{
			

			String code = textBox5.Text;

			if (code == "ACB")
			{
				label14.Text = "$ " + String.Format("{0:N2}", bal);
				label15.Text = "Customer Name: " + custname;
			}
			else
			{
				label14.Text = "Invalid PIN";
				textBox5.Text = "Try Again!";
				Refresh();
			}
		}

		private void label7_Click(object sender, EventArgs e)
		{
			//Label Click Cancel
		}

		private void button5_Click(object sender, EventArgs e)
		{
			DialogResult iExit;
			iExit = MessageBox.Show("Confirm do you want to cancel?", "ATM System", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
			if (iExit == DialogResult.Yes)
			{
				Application.Exit();
			}
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			
		}
		
		private void textBox7_TextChanged(object sender, EventArgs e)
		{
			bal = double.Parse(textBox7.Text);
			button1.Enabled = true;

		}

		private void textBox8_TextChanged(object sender, EventArgs e)
		{
			textBox8.Visible = true;
			textBox8.Enabled = false;
		}

		private void label9_Click(object sender, EventArgs e)
		{
			// Customer Name
		}

		private void label11_Click(object sender, EventArgs e)
		{
			//Customer Balance Request
		}

		private void label12_Click(object sender, EventArgs e)
		{
			//Show Customer Name
		}

		private void label13_Click(object sender, EventArgs e)
		{
			//Show Customer Total Balance
		}

		private void label14_Click(object sender, EventArgs e)
		{
			//Customer Name
		}

		private void label15_Click(object sender, EventArgs e)
		{
			//Customer Withdrawal Balance
		}
	}
}
